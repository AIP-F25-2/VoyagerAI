This directory contains standalone scripts.

Use `../cli.py` for DB-integrated commands.


